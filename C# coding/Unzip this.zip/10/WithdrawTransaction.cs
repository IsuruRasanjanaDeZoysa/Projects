using System;
using System.Collections.Generic;

public class WithdrawTransaction : Transaction
{
    private Account _account;

    public WithdrawTransaction(Account account, decimal amount) : base(amount)
    {
        _account = account;
    }

    public override void Execute()
    {
        if (_executed)
        {
            throw new InvalidOperationException("Transaction has already been executed.");
        }

        _executed = true;

        if (_account.Balance >= _amount)
        {
            _account.Withdraw(_amount);
            _success = true;
            _dateStamp = DateTime.Now;
        }
        else
        {
            throw new InvalidOperationException("Insufficient funds.");
        }
    }

    public override void Rollback()
    {
        if (!_executed)
        {
            throw new InvalidOperationException("Transaction has not been executed.");
        }

        if (_reversed)
        {
            throw new InvalidOperationException("Transaction has already been reversed.");
        }

        if (_success)
        {
            _account.Deposit(_amount);
            _reversed = true;
            _dateStamp = DateTime.Now;
        }
    }

    public override void Print()
    {
        Console.WriteLine("Withdraw Transaction:");
        Console.WriteLine($"Account: {_account.AccountNumber}, Withdrew Amount: {_amount}, Account Balance: {_account.Balance}");
        Console.WriteLine($"Transaction Executed: {_executed}, Transaction Successful: {_success}, Transaction Reversed: {_reversed}");
        Console.WriteLine($"Transaction Date Stamp: {_dateStamp}");
    }
}
