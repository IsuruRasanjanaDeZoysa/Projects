using System;
using System.Collections.Generic;

public class TransferTransaction : Transaction
{
    private Account _fromAccount;
    private Account _toAccount;

    public TransferTransaction(Account fromAccount, Account toAccount, decimal amount) : base(amount)
    {
        _fromAccount = fromAccount;
        _toAccount = toAccount;
    }

    public override void Execute()
    {
        if (_executed)
        {
            throw new InvalidOperationException("Transaction has already been executed.");
        }

        _executed = true;

        if (_fromAccount.Balance >= _amount)
        {
            _fromAccount.Withdraw(_amount);
            _toAccount.Deposit(_amount);
            _success = true;
            _dateStamp = DateTime.Now;
        }
        else
        {
            throw new InvalidOperationException("Insufficient funds for the transfer.");
        }
    }

    public override void Rollback()
    {
        if (!_executed)
        {
            throw new InvalidOperationException("Transaction has not been executed.");
        }

        if (_reversed)
        {
            throw new InvalidOperationException("Transaction has already been reversed.");
        }

        if (_success)
        {
            _toAccount.Withdraw(_amount);
            _fromAccount.Deposit(_amount);
            _reversed = true;
            _dateStamp = DateTime.Now;
        }
    }

    public override void Print()
    {
        Console.WriteLine("Transfer Transaction:");
        Console.WriteLine($"From Account: {_fromAccount.AccountNumber}, To Account: {_toAccount.AccountNumber}, Transfer Amount: {_amount}");
        Console.WriteLine($"Transaction Executed: {_executed}, Transaction Successful: {_success}, Transaction Reversed: {_reversed}");
        Console.WriteLine($"Transaction Date Stamp: {_dateStamp}");
    }
}