using System;
using System.Collections.Generic;

public abstract class Transaction
{
    protected decimal _amount;
    protected bool _success = false;
    protected bool _executed = false;
    protected bool _reversed = false;
    protected DateTime _dateStamp;
    //there is another way to define read only properties
    public bool Success => _success;   
    public bool Executed => _executed;
    public bool Reversed => _reversed;
    public DateTime DateStamp => _dateStamp;

    public Transaction(decimal amount)
    {
        _amount = amount;
    }

    public abstract void Execute();
    public abstract void Rollback();
    public abstract void Print();
}
