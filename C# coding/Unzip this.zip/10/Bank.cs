using System;
using System.Collections.Generic;

public class Bank
{
    private List<Account> _accounts = new List<Account>();
    private List<Transaction> _transactions = new List<Transaction>();

    public void AddAccount(Account account)
    {
        _accounts.Add(account);
    }

    public Account GetAccount(string name)
    {
        return _accounts.Find(account => account.Name == name);
    }

    public void ExecuteTransaction(Transaction transaction)
    {
        transaction.Execute();
        _transactions.Add(transaction);
        transaction.Print();
    }

    public void RollbackTransaction(Transaction transaction)
    {
        transaction.Rollback();
        transaction.Print();
    }

    public List<Transaction> GetTransactions()
    {
        return _transactions;
    }
}