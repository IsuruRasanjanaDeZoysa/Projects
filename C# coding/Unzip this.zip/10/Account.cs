using System;
using System.Collections.Generic;

public class Account
{
    public string AccountNumber { get; private set; }
    public string Name { get; private set; }
    public decimal Balance { get; private set; }

    public Account(string name, string accountNumber, decimal initialBalance)
    {
        AccountNumber = accountNumber;
        Balance = initialBalance;
        Name = name;
    }

    public void Deposit(decimal amount)
    {
        if (amount > 0)
        {
            Balance += amount;
        }
        else
        {
            throw new ArgumentException("Invalid deposit amount.");
        }
    }

    public void Withdraw(decimal amount)
    {
        if (amount > 0 && amount <= Balance)
        {
            Balance -= amount;
        }
        else
        {
            throw new ArgumentException("Invalid withdrawal amount.");
        }
    }
}