using System;
using System.Collections.Generic;

public class BankSystem
{
    private Bank _bank = new Bank();

    public void AddAccount()
    {
        Console.WriteLine("Enter account name:");
        string name = Console.ReadLine();
        Console.WriteLine("Enter account number:");
        string accountNumber = Console.ReadLine();
        Console.WriteLine("Enter initial balance:");
        decimal initialBalance = decimal.Parse(Console.ReadLine());

        Account newAccount = new Account(name, accountNumber, initialBalance);
        _bank.AddAccount(newAccount);

        Console.WriteLine($"Account {newAccount.Name} created with account number {newAccount.AccountNumber}.");
    }

    public void DoPrint()
    {
        Console.WriteLine("Enter account name:");
        string accountName = Console.ReadLine();
        Account account = FindAccount(accountName);

        if (account == null)
        {
            Console.WriteLine("Account not found.");
            return;
        }

        Console.WriteLine($"Account Information:\nAccount Number: {account.AccountNumber}\nName: {account.Name}\nBalance: {account.Balance}");
    }

    public void PrintTransactionHistory()
    {
        List<Transaction> transactions = _bank.GetTransactions();
        Console.WriteLine("Transaction History:");
        for (int i = 0; i < transactions.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {transactions[i].GetType().Name}");
            transactions[i].Print();
            Console.WriteLine();
        }
    }

    public void RollbackTransaction()
    {
        Console.WriteLine("Enter the index of the transaction to rollback:");
        if (int.TryParse(Console.ReadLine(), out int index) && index >= 1 && index <= _bank.GetTransactions().Count)
        {
            Transaction transaction = _bank.GetTransactions()[index - 1];
            try
            {
                _bank.RollbackTransaction(transaction);
                Console.WriteLine("Transaction rolled back successfully.");
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }
        else
        {
            Console.WriteLine("Invalid input. Please enter a valid transaction index.");
        }
    }

    private Account FindAccount(string name)
    {
        Console.WriteLine("Please wait...");
        Account account = _bank.GetAccount(name);

        if (account == null)
        {
            Console.WriteLine("Account not found.");
        }

        return account;
    }

    public void Run()
    {
        bool exitBankSystem = false;

        while (!exitBankSystem)
        {
            Console.WriteLine("\nWelcome to the Banking System!");
            Console.WriteLine("1. Add Account");
            Console.WriteLine("2. Deposit");
            Console.WriteLine("3. Withdraw");
            Console.WriteLine("4. Transfer");
            Console.WriteLine("5. Print Account Info");
            Console.WriteLine("6. Print Transaction History");
            Console.WriteLine("7. Rollback Transaction");
            Console.WriteLine("8. Exit!");
            Console.Write("Select an option: ");

            int choice;
            if (int.TryParse(Console.ReadLine(), out choice))
            {
                switch (choice)
                {
                    case 1:
                        AddAccount();
                        break;
                    case 2:
                        Console.WriteLine("Enter account name:");
                        string accountName = Console.ReadLine();
                        Account account = FindAccount(accountName);

                        if (account == null)
                        {
                            Console.WriteLine("Account not found.");
                        }
                        else
                        {
                            Console.WriteLine("Enter deposit amount:");
                            decimal amount = decimal.Parse(Console.ReadLine());
                            _bank.ExecuteTransaction(new DepositTransaction(account, amount));
                        }
                        break;
                    case 3:
                        Console.WriteLine("Enter account name:");
                        accountName = Console.ReadLine();
                        account = FindAccount(accountName);

                        if (account == null)
                        {
                            Console.WriteLine("Account not found.");
                        }
                        else
                        {
                            Console.WriteLine("Enter withdrawal amount:");
                            decimal amount = decimal.Parse(Console.ReadLine());
                            _bank.ExecuteTransaction(new WithdrawTransaction(account, amount));
                        }
                        break;
                    case 4:
                        Console.WriteLine("Enter source account name:");
                        string sourceAccountName = Console.ReadLine();
                        Account sourceAccount = FindAccount(sourceAccountName);

                        Console.WriteLine("Enter target account name:");
                        string targetAccountName = Console.ReadLine();
                        Account targetAccount = FindAccount(targetAccountName);

                        if (sourceAccount == null || targetAccount == null)
                        {
                            Console.WriteLine("One or both accounts not found.");
                        }
                        else
                        {
                            Console.WriteLine("Enter transfer amount:");
                            decimal amount = decimal.Parse(Console.ReadLine());
                            _bank.ExecuteTransaction(new TransferTransaction(sourceAccount, targetAccount, amount));
                        }
                        break;
                    case 5:
                        DoPrint();
                        break;
                    case 6:
                        PrintTransactionHistory();
                        break;
                    case 7:
                        RollbackTransaction();
                        break;
                    case 8:
                        exitBankSystem = true;
                        Console.WriteLine("Exiting from Banking System");
                        break;
                    default:
                        Console.WriteLine("Invalid selection! Please select a valid option again.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("Invalid input! Please enter a number.");
            }

            if (!exitBankSystem)
            {
                Console.WriteLine("Press any key to continue...");
                Console.ReadKey();
                Console.Clear();
            }
        }
    }

    static void Main(string[] args)
    {
        BankSystem bankSystem = new BankSystem();
        bankSystem.Run();
    }
}
