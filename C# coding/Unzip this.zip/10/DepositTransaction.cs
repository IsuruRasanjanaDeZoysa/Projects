using System;
using System.Collections.Generic;

public class DepositTransaction : Transaction
{
    private Account _account;

    public DepositTransaction(Account account, decimal amount) : base(amount)
    {
        _account = account;
    }

    public override void Execute()
    {
        if (_executed)
        {
            throw new InvalidOperationException("Transaction has already been executed.");
        }

        _executed = true;

        _account.Deposit(_amount);
        _success = true;
        _dateStamp = DateTime.Now;
    }

    public override void Rollback()
    {
        if (!_executed)
        {
            throw new InvalidOperationException("Transaction has not been executed.");
        }

        if (_reversed)
        {
            throw new InvalidOperationException("Transaction has already been reversed.");
        }

        if (_success)
        {
            _account.Withdraw(_amount);
            _reversed = true;
            _dateStamp = DateTime.Now;
        }
    }

    public override void Print()
    {
        Console.WriteLine("Deposit Transaction:");
        Console.WriteLine($"Account: {_account.AccountNumber}, Deposit Amount: {_amount}, Account Balance: {_account.Balance}");
        Console.WriteLine($"Transaction Executed: {_executed}, Transaction Successful: {_success}, Transaction Reversed: {_reversed}");
        Console.WriteLine($"Transaction Date Stamp: {_dateStamp}");
    }
}
