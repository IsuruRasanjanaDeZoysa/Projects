﻿using System;

namespace ExceptionHandling
{

    class Account
    {
        public string FirstName { get; private set; }
        public string LastName { get; private set; }
        public int Balance { get; private set; }

        public Account(string firstName, string lastName, int balance)
        {
            FirstName = firstName;
            LastName = lastName;
            Balance = balance;
        }

        public void Withdraw(int amount)
        {
            if (amount > Balance)
            {
                throw new InvalidOperationException("Insufficient fund");
            }
            Balance = Balance - amount;
        }

        public Account MakeAnotherAcc()
        {
            if (Balance > 0)
            {
                return new Account(FirstName, LastName + " second account", Balance / 2);
            }
            else
            {
                return null;
            }
        }
    }
    class MyClass
    {
        int number;
        int[] array;
        public MyClass(int number_)
        {
            number = number_;
        }
        public MyClass(int number_, int[] array_)
        {
            number = number_;
            array = array_;
        }
        public void Divide(int denominator)
        {
            if (denominator == 0)
            {
                throw new DivideByZeroException("Denominator is zero");
            }
            else
            {
                Console.WriteLine("value" + number/denominator);
            }
        }
        public void PrintName(string name)
        {
            if (name != null)
            {
                Console.WriteLine("Name is :" + name);
            }
            else
            {
                throw new ArgumentNullException(nameof(name), "Value cannot be null");
            }
        }
        public void PrintElement(int index)
        {
            if (index < array.Length)
            {
                Console.WriteLine("Element value :"+array[index]);
            }
            else
            {
                throw new ArgumentOutOfRangeException(nameof(index), "index is out of range");
            }
        }
        public void PrintAge(int age)
        {
            if (age > 0 && age < 120){
                Console.WriteLine("Age is :" + age);
            }
            else
            {
                throw new ArgumentException("Age must be between 0 and 120.", nameof(age));
            }


        }


    }

    class Program
    {
        public static void Main()
        {
            //NullReferenceException
            //Here a new account is created if balance is greater than zero. It's starting balance will be half of the balance of the main account. An exception will occure if the balance is zero.
            try
            {
                Account account = new Account("Sergey", "P", 0);

                Console.WriteLine("Balance of the second account is : " + account.MakeAnotherAcc().Balance);
            }
            catch (NullReferenceException exception)
            {
                Console.WriteLine("The following error detected: " + exception.GetType().ToString() + " with message \"" + exception.Message + "\"");
            }


            //IndexOutOfRangeException
            try
            {
                int[] numbers = { 2, 4, 6, 8, 10 };
                Console.WriteLine(numbers[9]);
            }
            catch (IndexOutOfRangeException exception)
            {
                Console.WriteLine("The following error detected: " + exception.GetType().ToString() + " with message \"" + exception.Message + "\"");
            }
            
            

            //StackOverflowException this exception is only trown by the runtime

            //OutOfMemoryException this exception is only trown by the runtime

            //DivideByZeroException 
            try
            {
                MyClass myClass = new MyClass(10);
                myClass.Divide(0);
            }
            catch (DivideByZeroException exception)
            {
                Console.WriteLine("The following error detected: " + exception.GetType().ToString() + " with message \"" + exception.Message + "\"");
            }

            //ArgumentNullException 
            try
            {
                MyClass myClass = new MyClass(10);
                myClass.PrintName(null);
            }
            catch (ArgumentNullException exception)
            {
                Console.WriteLine("The following error detected: " + exception.GetType().ToString() + " with message \"" + exception.Message + "\"");
            }

            //ArgumentOutOfRangeException
            try
            {
                MyClass myClass = new MyClass(10, new int[] { 10, 20, 30, 40, 50 });
                myClass.PrintElement(8);
            }
            catch (ArgumentOutOfRangeException exception)
            {
                Console.WriteLine("The following error detected: " + exception.GetType().ToString() + " with message \"" + exception.Message + "\"");

            }

            //FormatException
            try
            {
                int.Parse("i"); //argument should be a string representation of an integer number
            }
            catch (FormatException exception)
            {
                Console.WriteLine("The following error detected: " + exception.GetType().ToString() + " with message \"" + exception.Message + "\"");
            }


            //ArgumentException
            try
            {
                MyClass myClass = new MyClass(10);
                myClass.PrintAge(160);
            }
            catch (ArgumentException exception)
            {
                Console.WriteLine("The following error detected: " + exception.GetType().ToString() + " with message \"" + exception.Message + "\"");
            }

            //SystemException 
            //this is the base class for all the exceptions defined by the CLR




        }
    }
}
