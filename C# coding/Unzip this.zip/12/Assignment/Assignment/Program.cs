﻿using Practical_8_1;
using Practical_Task_3._2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace Assignment
{
    public class Tester
    {
        public static void Main(string[] args)
        {
            MyStack<Account> Stack = new MyStack<Account>(10);
            Stack.Push(new Account("Acc:1", 10000));
            Stack.Push(new Account("Acc:2", 20000));
            Stack.Push(new Account("Acc:2", 12000));
            Stack.Push(new Account("Acc:3", 10000));
            Stack.Push(new Account("Acc:4", 70000));
            Stack.Push(new Account("Acc:5", 2000));
            Stack.Push(new Account("Acc:6", 0));
            Stack.Push(new Account("Acc:7", 800));
            Stack.Push(new Account("Acc:8-credit account", 100));
            Stack.Push(new Account("Acc:9-short term deposit", 100));

            Console.WriteLine("Tests for Find() method");
            //find an account which balance equals to 70000
            Console.WriteLine(Stack.Find(x => x.Balance == 70000).Name);
            //find accounts that balance is less than 1000
            Console.WriteLine(Stack.Find(x => x.Balance < 100).Name);

            //returns an ArgumentNullException when criteria is null
            //Account foundAcc=Stack.Find(null);

            //NullReferenceException-because there is not an account which balance equals to 110
            //Console.WriteLine(Stack.Find(x => x.Balance ==110).Name);

            //search for an account with a strictly positive balance
            Console.WriteLine(Stack.Find(x => x.Balance >0).Name);
            Console.WriteLine();
            Console.WriteLine();


            Console.WriteLine("Tests for FindAll() method");
            //find all account with balance equals to 10000. 
            Account[] accounts = Stack.FindAll(x => x.Balance == 10000);
            for(int i=0; i< accounts.Length; i++)
            {
                Console.Write(accounts[i].Name+" ");
            }
            Console.WriteLine();

            //find all account with name equals to Acc:2
            accounts = Stack.FindAll(x => x.Name == "Acc:2");
            for (int i = 0; i < accounts.Length; i++)
            {
                Console.Write(accounts[i].Name + " ");
            }
            Console.WriteLine();

            //find accounts related to credit cards
            accounts = Stack.FindAll(x => Regex.IsMatch(x.Name, @"\bcredit\b", RegexOptions.IgnoreCase));
            for (int i = 0; i < accounts.Length; i++)
            {
                Console.Write(accounts[i].Name + " ");
            }
            Console.WriteLine();

            //find accounts related to short term deposits
            accounts = Stack.FindAll(x => Regex.IsMatch(x.Name, @"\bshort term deposit\b", RegexOptions.IgnoreCase));
            for (int i = 0; i < accounts.Length; i++)
            {
                Console.Write(accounts[i].Name + " ");
            }
            Console.WriteLine(); 
            Console.WriteLine();

            Console.WriteLine("Tests for RemoveAll() method");
            //remove all the accounts which balance equal to 10000. 
            //this should print 2
            int numOfRemovedAcc=Stack.RemoveAll(x=>x.Balance == 10000);
            Console.WriteLine(numOfRemovedAcc);

            //return an ArgumentNullException
            //numOfRemovedAcc = Stack.RemoveAll(null);

            //remove all the accounts which name equals to Acc:2 this will print 2
            numOfRemovedAcc = Stack.RemoveAll(x => x.Name == "Acc:2");
            Console.WriteLine(numOfRemovedAcc);

            //removes accounts which have "credit" in its name this will print 1
            numOfRemovedAcc = Stack.RemoveAll(x => Regex.IsMatch(x.Name, @"\bcredit\b", RegexOptions.IgnoreCase));
            Console.WriteLine(numOfRemovedAcc);

            //removes accounts which have "short term deposit" in its name this will print 1
            numOfRemovedAcc = Stack.RemoveAll(x => Regex.IsMatch(x.Name, @"\bshort term deposit\b", RegexOptions.IgnoreCase));
            Console.WriteLine(numOfRemovedAcc);

            Console.WriteLine();
            Console.WriteLine();

            Console.WriteLine("Tests for Max() method");
            //print bank account name with maximum balance. This will print Acc:4
            Console.WriteLine(Stack.Max().Name);
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Tests for Min() method");
            //print bank account name with minimum balance. This should print Acc:6
            Console.WriteLine(Stack.Min().Name);

        }
    }
}
