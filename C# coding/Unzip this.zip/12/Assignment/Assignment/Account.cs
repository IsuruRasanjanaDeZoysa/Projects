﻿using System;

namespace Practical_Task_3._2
{
    public class Account: IComparable<Account>
    {
        private string _name; // Account holder's name
        private decimal _balance;

        public decimal Balance
        { get { return _balance; } }

        //I added this getter because it helps when printing account name rather than account balance in test cases
        public string Name
        { get { return _name; } }

        // Constructor now requires an account holder's name and initial balance
        public Account(string name, decimal initialBalance)
        {
            _name = name;
            _balance = initialBalance;
        }



        public bool Deposit(decimal amount)
        {
            if (amount > 0)
            {
                _balance += amount;
                return true;
            }
            return false;
        }

        public bool Withdraw(decimal amount)
        {
            if (amount > 0 && _balance >= amount)
            {
                _balance -= amount;
                return true;
            }
            return false;
        }

        // Print method now also displays the account holder's name
        public void Print()
        {
            Console.WriteLine($"{_name}'s Current balance: {_balance:C}");
        }

        
        public int CompareTo(Account other)
        {
            if(_balance < other._balance) return -1;
            if( _balance > other._balance) return 1;
            return 0;
        }
    }


}
