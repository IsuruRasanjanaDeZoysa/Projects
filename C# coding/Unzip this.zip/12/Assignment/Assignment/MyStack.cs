﻿using System;
using System.Collections.Generic;

namespace Practical_8_1
{

    public class MyStack<T>
    {
        public T[] array;
        public int Count { get; private set; }

        public MyStack(int capacity)
        {
            array = new T[capacity];
            this.Count = 0;
        }

        public void Push(T val)
        {
            if (Count < array.Length) array[Count++] = val;
            else throw new InvalidOperationException("The stack is out of capacity.");
        }

        public T Pop()
        {
            if (Count > 0) return array[--Count];
            else throw new InvalidOperationException("The stack is empty.");
        }

        public T Find(Func<T, bool> criteria)
        {
            if (criteria == null) throw new ArgumentNullException();

            for (int i = Count - 1; i >= 0; i--)
            {
                if (criteria(array[i]))
                {
                    return array[i];
                }
            }
            return default(T);
        }

        public T[] FindAll(Func<T, bool> criteria)
        {
            if (criteria == null) throw new ArgumentNullException();
            int count = 0;
            for (int i = Count - 1; i >= 0; i--)
            {
                if (criteria(array[i]))
                {
                    count++;
                }
            }
            if (count == 0)
            {
                return null;
            }
            T[] foundValues = new T[count];
            int index = 0;
            for (int i = Count - 1; i >= 0; i--)
            {
                if (criteria(array[i]))
                {
                    foundValues[index++] = array[i];
                }
            }
            return foundValues;
        }

        public int RemoveAll(Func<T, bool> criteria)
        {
            if (criteria == null) throw new ArgumentNullException();
            int numberOfRemovedItems = 0;
            T[] removedItems = FindAll(criteria);
            if(removedItems == null)
            {
                return 0;
            }
            numberOfRemovedItems = removedItems.Length;
            int newCount = Count - numberOfRemovedItems;
            
            T[] newStack = new T[newCount];
            int index = 0;
            for (int i = 0; i < Count; i++)
            {
                bool terminated = false;
                for (int j = 0; j < numberOfRemovedItems; j++)
                {
                    if (EqualityComparer<T>.Default.Equals(array[i], removedItems[j]))
                    {
                        terminated = true;
                        break;
                    }
                }
                if (!terminated)
                {
                    newStack[index++] = array[i];
                }
            }
            array = newStack;
            Count = newCount;
            return numberOfRemovedItems;
        }

        public T Max()
        {
            T max = array[0];
            for(int i = 1; i < Count; ++i) 
            {
                
                if (Comparer<T>.Default.Compare(array[i], max) > 0)
                {
                    max = array[i];
                }
            }            
            return max;
        }

        public T Min()
        {
            T min = array[0];
            for (int i = 1; i < Count; ++i)
            {
                if (Comparer<T>.Default.Compare(array[i], min) < 0)
                {
                    min = array[i];
                }
            }
            return min;
        }
    }
}