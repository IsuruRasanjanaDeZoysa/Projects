﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class DepositTransaction : Transaction
    {
        private Account _account;


        public DepositTransaction(Account account, decimal amount) : base(amount)
        {
            _account = account;
        }

        

        public override void Print()
        {
            Console.WriteLine("Transaction Summary");
            if (_success)
            {
                Console.WriteLine("Status : Sucess");
                Console.WriteLine("Deposited To:    {0}", _account.Name);
                Console.WriteLine("Amount:          {0}", _amount.ToString("C"));
                Console.WriteLine(_dateStamp.ToString());
            }
            else
            {
                Console.WriteLine("Status : Failed");
                Console.WriteLine("Deposited To:    {0}", _account.Name);
                Console.WriteLine("Amount:          {0}", _amount.ToString("C"));
                Console.WriteLine(_dateStamp.ToString());
            }
        }

        public void RollbackPrint()
        {
            Console.WriteLine("Transaction Summary");
            Console.WriteLine("Rollback Withdrwan from:    {0}", _account.Name);
            Console.WriteLine("Amount:                     {0}", _amount.ToString("C"));
        }

        public override void Execute()
        {
            if (_executed)
            {
                throw new InvalidOperationException("You've already made this deposit successfully.");
            }
            _executed = true;
            _success = _account.Deposit(_amount);
            _dateStamp = DateTime.Now;

            if (!_success)
            {
                throw new InvalidOperationException("The value you entered must be greater than zero.");
            }
        }

        public override void Rollback()
        {
            if (!_success)
            {
                throw new InvalidOperationException("Deposit failed.");
            }
            else if (_reversed)
            {
                throw new InvalidOperationException("This rollback cannot be processed again.");
            }

            _reversed = _account.Withdraw(_amount);
            if (!_reversed)
            {
                throw new InvalidOperationException("Rollback could not be completed");
            }
            _reversed = true;
        }
    }
}