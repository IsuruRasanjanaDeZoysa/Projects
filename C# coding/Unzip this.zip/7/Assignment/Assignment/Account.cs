﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    public class Account
    {
        private decimal _balance;
        private readonly string _name;
        private readonly string _account_number;

        public String Name
        {
            get
            {
                return _name;
            }
        }
        public decimal Balance
        {
            get
            {
                return _balance;
            }
        }
        public string AccountNumber
        {
            get {
                return _account_number;
            }
        }

        public Account(String name, decimal initialbalance)
        {
            _name = name;
            _balance = initialbalance;
        }

        public Account(String name, String account_number,Decimal initial_balance)
        {
            _name = name;
            _balance = initial_balance;
            _account_number = account_number;
        }

        public bool Deposit(decimal amount)
        {
            if (amount > 0)
            {
                _balance += amount;
                return true;
            }
            return false;
        }

        public bool Withdraw(decimal amount)
        {
            if (amount > 0 && amount <= _balance)
            {
                _balance -= amount;
                return true;
            }
            return false;
        }

        public void Print()
        {
            Console.WriteLine("Account Name: " + _name + ", Balance: " + _balance);
        }

    }

}