﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Assignment
{
    enum MenuOption
    {
        addAccount,
        Withdraw,
        Deposit,
        Transfer,
        Print,
        PrintHistory,
        Quit
    }

    class BankSystem
    {
        
        public static MenuOption ReadUserOption()
        {
            int choice;
            do
            {
                //below lines print the option menu
                Console.WriteLine("_____________________\nChoose an option:");
                Console.WriteLine("");
                Console.WriteLine("1. Add new account");
                Console.WriteLine("2. Withdraw");
                Console.WriteLine("3. Deposit");
                Console.WriteLine("4. Transfer");
                Console.WriteLine("5. Print Details");
                Console.WriteLine("6. Print Transaction History");
                Console.WriteLine("7. Quit");
                Console.Write("Enter your choice: ");
                if (int.TryParse(Console.ReadLine(), out choice) && Enum.IsDefined(typeof(MenuOption), choice - 1))
                    return (MenuOption)(choice - 1);
                else
                    Console.WriteLine("Invalid option. Please choose a valid option.");

            } while (true);

        }
        //method to withdraw money
        public static void DoWithdraw(Bank bank)         
        {
            Console.WriteLine("Enter account name: ");
            Account account = FindAccount(bank);
            Console.WriteLine("Enter the amount to withdraw: ");
            decimal amount = decimal.Parse(Console.ReadLine());

            try
            {
                WithdrawTransaction withdraw = new WithdrawTransaction(account, amount);
                bank.ExecuteTransaction(withdraw);                
                withdraw.Print();
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine("Withdrawal failed: " + ex.Message); 
            }
        }

        //method to deposit money
        public static void DoDeposit(Bank bank)
        {
            Console.WriteLine("Enter account name: ");
            Account account = FindAccount(bank);    //search using account name
            Console.WriteLine("Enter the amount to deposit: ");
            decimal amount = decimal.Parse(Console.ReadLine());

            try
            {
                DepositTransaction deposit = new DepositTransaction(account, amount);
                bank.ExecuteTransaction(deposit);
                deposit.Print();
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine("Deposit failed: " + ex.Message); 
            }
        }

        //method to transfer money
        public static void DoTransfer(Bank bank)  
        {
            Console.WriteLine("Enter your account name: ");
            Account senders_account= FindAccount(bank);
            Console.WriteLine("Enter beneficiary's account name: ");
            Account beneficiary_account= FindAccount(bank);
            Console.WriteLine("Enter amount to transfer: ");
            decimal amount = decimal.Parse(Console.ReadLine());
            

            try
            {
                TransferTransaction transfer = new TransferTransaction(senders_account, beneficiary_account, amount);
                bank.ExecuteTransaction(transfer);
                transfer.Print();
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine("Transfer Unsuccessful : " + ex.Message);
            }
        }

        //method to print money
        public static void DoPrint(Bank bank) 
        {
            Console.WriteLine("Enter your account name: ");
            Account account = FindAccount(bank);
            account.Print();
        }

        //when the index of a transation is given this method Rollbacks it
        public static void DoRollback(Bank bank)
        {
            Console.WriteLine("Do you want to Rollback a transaction ?   Yes or No");
            string answer= Console.ReadLine().ToLower();
            if (answer == "yes")
            {
                Console.WriteLine("Enter index of the transaction to Rollback");
                int index = int.Parse(Console.ReadLine()) - 1;
                bank.Transactions[index].Rollback();
            }
                
        }

        public static void Main(string[] args)
        {
            

            Bank bank=new Bank();

            MenuOption option;

            do
            {
                option = ReadUserOption();
                Console.WriteLine("You selected option: " + option);
                switch (option)
                {
                    case MenuOption.addAccount:
                        Add_account(bank);
                        break;

                    case MenuOption.Withdraw:
                        DoWithdraw(bank);
                        break;
                    case MenuOption.Deposit:
                        DoDeposit(bank);
                        break;
                    case MenuOption.Transfer:
                        DoTransfer(bank);
                        break;
                    case MenuOption.Print:
                        DoPrint(bank);
                        break;
                    case MenuOption.PrintHistory:
                        bank.PrintTransactionHistory();
                        DoRollback(bank);
                        break;
                    case MenuOption.Quit:
                        Console.WriteLine("Exiting program.");
                        break;
                }
            } while (option != MenuOption.Quit);
        }

        //method to add accounts
        public static void Add_account(Bank _bank)
        {
            Console.WriteLine("Enter account name :");
            string name = Console.ReadLine();
            Console.WriteLine("Enter account number :");
            string accountNumber = Console.ReadLine();
            Console.WriteLine("Enter initial balance :");
            decimal initialBalance;
            try
            {
                initialBalance = decimal.Parse(Console.ReadLine());
                Account newAccount = new Account(name, accountNumber, initialBalance);
                _bank.AddAccount(newAccount);

                Console.WriteLine($"Account {newAccount.Name} created with account number {newAccount.AccountNumber}.");
            }
            catch (FormatException e)
            {
                Console.WriteLine("Invalid input. Please enter a valid decimal number !");
                Add_account(_bank);
                
            }

            
        }

        //method to find accounts
        private static Account FindAccount(Bank _bank)
        {
            
            String name = Console.ReadLine();
            Account account = _bank.GetAccount(name);
            Console.WriteLine("Searching...");            

            if (account == null)
            {
                Console.WriteLine("Account not found !");
            }

            return account;
        }
    }
}