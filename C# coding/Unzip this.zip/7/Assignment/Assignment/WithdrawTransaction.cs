﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class WithdrawTransaction:Transaction
    {
        private Account _account;


        public WithdrawTransaction(Account account, decimal amount) : base(amount)
        {
            _account = account;
        }

        

        public override void Print()
        {
            Console.WriteLine("Transaction Summary");
            if (_success)
            {
                Console.WriteLine("Status : Sucess");
                Console.WriteLine("Withdrawn From:    {0}", _account.Name);
                Console.WriteLine("Amount:            {0}", _amount.ToString("C"));
                Console.WriteLine(_dateStamp.ToString());
            }
            else
            {
                Console.WriteLine("Status : Failed");
                Console.WriteLine("Deposited To:    {0}", _account.Name);
                Console.WriteLine("Amount:          {0}", _amount.ToString("C"));
                Console.WriteLine(_dateStamp.ToString());
            }
        }

        public  void RollbackPrint()
        {
            Console.WriteLine("Transaction Summary");
            Console.WriteLine("Rollback Deposited To:    {0}", _account.Name);
            Console.WriteLine("Amount:                   {0}", _amount.ToString("C"));
    
        }

        public override void Execute()
        {
            if (_executed)
            {
                throw new InvalidOperationException("You've already made this withdraw successfully.");
            }
            _executed = true;
            _success = _account.Withdraw(_amount);
            _dateStamp = DateTime.Now;
            if (!_success)
            {
                throw new InvalidOperationException("The entered amount is either not positive or exceeds your available balance.");
            }
        }

        public override void Rollback()
        {
            if (!_success)
            {
                throw new InvalidOperationException("Withdrawal failed");
            }
            else if (_reversed)
            {
                throw new InvalidOperationException("This rollback cannot be processed again.");
            }
            _reversed = _account.Deposit(_amount);
            if (!_reversed)
            {
                throw new InvalidOperationException("Rollback could not be completed");
            }
            _reversed = true;
        }
    }
}