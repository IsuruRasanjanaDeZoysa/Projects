﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class TransferTransaction : Transaction
    {
        private Account _fromAccount;
        private Account _toAccount;
        DepositTransaction _deposit;
        WithdrawTransaction _withdraw;

        public TransferTransaction(Account fromAccount, Account toAccount, decimal amount) : base(amount)
        {
            _fromAccount = fromAccount;
            _toAccount = toAccount;
            _withdraw = new WithdrawTransaction(_fromAccount, _amount);
            _deposit = new DepositTransaction(_toAccount, _amount);
        }

        public override void Execute()
        {
            if (_executed)
            {
                throw new InvalidOperationException("This transfer cannot be processed again.");
            }
            _executed = true;
            _withdraw.Execute();

            if (_withdraw.Success)
            {
                try
                {
                    _deposit.Execute();       
                }
                catch (InvalidOperationException)
                {
                    Console.WriteLine("Transaction could not be completed");
                    try
                    {
                        Rollback();   
                        _success = true;
                        _dateStamp = DateTime.Now;
                    }
                    catch (InvalidOperationException)
                    {
                        Console.WriteLine("Rollback could not be completed");
                    }
                }
            }
        }

        

        public override void Print()
        {
            if (_success)
            {
                Console.WriteLine("Status : Sucess");
                Console.WriteLine("Transaction Summary");
                Console.WriteLine("From:  {0} ({1})", _fromAccount.Name, _fromAccount.Balance.ToString("C"));
                Console.WriteLine("To:    {0} ({1})", _toAccount.Name, _toAccount.Balance.ToString("C"));
                Console.WriteLine("Amount: {0}", _amount.ToString("C"));
                Console.WriteLine(_dateStamp.ToString());
            }

            else
            {
                Console.WriteLine("Withdrawal details:");     //see if this part is required
                _withdraw.Print();
                Console.WriteLine("Deposit details:");
                _deposit.Print();
            }
        }

        public void RollbackPrint()
        {
            Console.WriteLine("Transaction Summary - Rollback Done");
            Console.WriteLine("From:  {0} ({1})", _fromAccount.Name, _toAccount.Balance.ToString("C"));
            Console.WriteLine("To:    {0} ({1})", _toAccount.Name, _fromAccount.Balance.ToString("C"));
            Console.WriteLine("Amount: {0}", _amount.ToString("C"));
        }

        

        public override void Rollback()
        {
            if (_reversed)
            {
                throw new InvalidOperationException("This rollback cannot be processed again.");
            }
            else if (!_withdraw.Success && !_deposit.Success)
            {
                throw new InvalidOperationException("Transaction could not be completed");
            }
            else
            {
                _deposit.Rollback();

                if (_deposit.Reversed)
                {
                    try
                    {
                        _withdraw.Rollback();
                    }
                    catch (InvalidOperationException)
                    {
                        Console.WriteLine("Rollback could not be completed");
                    }
                }
            }
            _reversed = true;
            _success = false;
        }
    }
}