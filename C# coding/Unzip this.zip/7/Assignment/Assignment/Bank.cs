using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class Bank
    {
        private List<Account> _accounts = new List<Account>();
        private List<Transaction> _transactions = new List<Transaction>();//to hold transactions

        public List<Transaction> Transactions
        {
            get { return _transactions; }
        }
        public void AddAccount(Account account)
        {
            _accounts.Add(account);
        }

        public Account GetAccount(string name)
        {
            Account account_ = null;
            account_=_accounts.Find(account => account.Name == name);
            return account_;
        }

        public void ExecuteTransaction(Transaction transaction)
        {
            _transactions.Add(transaction);
            transaction.Execute();
            transaction.Print();
        }

        //when a transaction is given this method rollbacks it
        public void RollbackTransaction(Transaction transaction) 
        {
            transaction.Rollback();
        }

        //prints all the transactions
        public void PrintTransactionHistory()
        {

            int i = 0;
            foreach (Transaction transaction in _transactions)
            {
                Console.WriteLine("(" +(i+1)+ ")");
                transaction.Print();
                Console.WriteLine();
                i++;
            }
        }
    }

}