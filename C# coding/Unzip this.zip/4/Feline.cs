﻿using ConsoleAppOne;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppTwo
{
    public class Feline:Animal
    {
        private String species;

        public Feline(String name, String diet, String location, double weight, int age, String colour, String species)
            :base(name,diet,location,weight,age,colour)
        {
            this.species = species; 
        }

        //this method overrides the sleep method in Animal class
        public override void sleep()
        {
            Console.WriteLine("Feeline animal sleeps");
        }
    }
}
