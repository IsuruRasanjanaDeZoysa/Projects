﻿using ConsoleAppTwo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppOne
{
    public class ZooPark
    {
        public static void Main(string[] args)
        {
            //Animal williamWolf = new Animal("William the Wolf", "Meat", "Dog Village", 50.6,9, "Grey");
            //Animal tonyTiger = new Animal("Tony the Tiger", "Meat", "Cat Land", 110, 6, "Orange and White");
            //Animal edgarEagle = new Animal("Edgar the Eagle", "Fish", "Bird Mania", 20, 15, "Black");

            Tiger tonyTiger = new Tiger("Tony the Tiger","Meat","Cat Land",110,6,"Orange and White","Siberian","White");
            Wolf williamWolf = new Wolf("William the Wolf", "Meat", "Dog Village", 50.6, 9, "Grey");
            Eagle edgarEagle = new Eagle("Edgar the Eagle", "Fish", "Bird Mania", 20, 15, "Black","Harpy",98.5);

            //3,step 2
            tonyTiger.makeNoise();
            Animal baseAnimal = new Animal("Animal Name", "Animal Diet", "Animal Location", 0.0, 0,"Animal Colour");
            baseAnimal.makeNoise();
            
            //3,step 3 and 4
            tonyTiger.eat();
            baseAnimal.eat();
            williamWolf.eat();
            edgarEagle.eat();

            //3,step 5
            tonyTiger.huntOrGetHunted();
            williamWolf.huntOrGetHunted();
            edgarEagle.huntOrGetHunted();
            baseAnimal.huntOrGetHunted();

            //4,step 3
            baseAnimal.sleep();
            tonyTiger.sleep();
            williamWolf.sleep();
            edgarEagle.sleep();
            tonyTiger.eat();

            //4,step 4
            Bird birdAnimal=new Bird("Bird Name", "Bird Diet", "Bird Location", 0.0, 0, "Bird Colour","Bird species",0.0);
            Penguin tutuPenguine = new Penguin("Tutu", "warms", "Antactica", 20, 2, "White and Black", "Gentoo", 1);
            birdAnimal.fly();
            tutuPenguine.fly();
            edgarEagle.fly();
        }
    }
}
