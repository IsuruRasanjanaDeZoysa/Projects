﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppOne
{
    public class Animal
    {
        private String name;
        private String diet;
        private String location;
        private double weight;
        private int age;
        private String color;


        //these are the constructor of Animal class
        public Animal(String name, String diet, String location, double weight, int age, String colour)
        {
            this.name = name;
            this.diet = diet;
            this.location = location;
            this.weight = weight;
            this.age = age;
            this.color = colour;
        }

        //these are the methods available in Animal class
        public virtual void eat()
        {
            Console.WriteLine("An animal eats");
        }

        public virtual void sleep()
        {
            Console.WriteLine("Animal sleeps");
        }

        public virtual void makeNoise()
        {
            Console.WriteLine("An animal makes a noise");
        }

        public virtual void huntOrGetHunted()
        {
            Console.WriteLine("Animal hunt or get hunted");
        }

        


    }
}
