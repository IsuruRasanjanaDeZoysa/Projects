﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppTwo
{
    public class Penguin: Bird
    {
        private String species;
        private double wingSpan;
        public Penguin(string name, string diet, string location, double weight, int age, string colour, String species, double wingSpan)
        : base(name, diet, location, weight, age, colour,species,wingSpan)
        {
        
        }

        //this method overrides the fly method in Animal class
        public override void fly()
        {
            Console.WriteLine("Penguine doen't fly"); ;
        }
    }
}
