﻿using ConsoleAppOne;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppTwo
{
    class Tiger : Feline
    {
        
        private String colourStripes;
        public Tiger(string name, string diet, string location, double weight, int age, string colour, String species, String colourStripes)
            : base(name, diet, location, weight, age, colour,species)
        {
            this.colourStripes = colourStripes;
        }

        
        public override void makeNoise()
        {
            Console.WriteLine("ROARRRRRRRRR");
        }

        public override void eat()
        {
            Console.WriteLine("I can eat 20lbs of meat");
        }

        //this method overrides the huntOrGetHunted method in Animal class
        public override void huntOrGetHunted()
        {
            Console.WriteLine("I hunt..I am a predetor");
        }

    }
}
