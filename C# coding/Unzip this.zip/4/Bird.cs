﻿using ConsoleAppOne;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppTwo
{
    public class Bird: Animal
    {
        private String species;
        private double wingSpan;
        public Bird(string name, string diet, string location, double weight, int age, string colour, String species, double wingSpan)
        : base(name, diet, location, weight, age, colour)
        {
            this.species = species;
            this.wingSpan = wingSpan;
        }

        public virtual void fly()
        {
            Console.WriteLine("Bird flies");
        }
    }
}
