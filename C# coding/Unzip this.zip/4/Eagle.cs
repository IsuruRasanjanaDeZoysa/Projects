﻿using ConsoleAppOne;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppTwo
{
    
    public class Eagle: Bird
    {
        private String species;
        private double wingSpan;
        public Eagle(string name, string diet, string location, double weight, int age, string colour, String species, double wingSpan)
        : base(name, diet, location, weight, age, colour, species, wingSpan)
        {
            this.species = species;
            this.wingSpan = wingSpan;
        }
        public void layEgg()
        {
            Console.WriteLine("Eagle lay eggs");
        }


        //Below methods overrides fly, makeNoise, eat, huntOrGetHunted methods in Animal class respectively

        public override void fly()
        {
            Console.WriteLine("Eagle flies");
        }

        public override void makeNoise()
        {
            Console.WriteLine("WHISTLES");
        }

        public override void eat()
        {
            Console.WriteLine("I can eat 1lb of fish");
        }

        public override void huntOrGetHunted()
        {
            Console.WriteLine("I don't hunt..I am a prey");
        }
    }
}
