﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppTwo
{
    public class Lion: Feline
    {
        private String colourStripes;
        public Lion(string name, string diet, string location, double weight, int age, string colour, String species, String colourStripes)
            : base(name, diet, location, weight, age, colour, species)
        {
            this.colourStripes = colourStripes;
        }
    }
}
