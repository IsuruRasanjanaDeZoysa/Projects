﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppOne
{
    public class ZooPark
    {
        //Here three instances are created from Animal class
        public static void Main(string[] args)
        {
            Animal williamWolf = new Animal("William the Wolf", "Meat", "Dog Village", 50.6,9, "Grey");
            Animal tonyTiger = new Animal("Tony the Tiger", "Meat", "Cat Land", 110, 6, "Orange and White");
            Animal edgarEagle = new Animal("Edgar the Eagle", "Fish", "Bird Mania", 20, 15, "Black");
        }
    }
}
