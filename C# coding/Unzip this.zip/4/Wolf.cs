﻿using ConsoleAppOne;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppTwo
{
    public class Wolf:Animal
    {
        public Wolf(string name, string diet, string location, double weight, int age, string colour)
            : base(name, diet, location, weight, age, colour)
        {
        
        }

        
        public override void makeNoise()
        {
            Console.WriteLine("HOWLS");
        }

        public override void eat()
        {
            Console.WriteLine("I can eat 10lbs of meat");
        }

        //this method overrides the huntOrGetHunted method in Animal class
        public override void huntOrGetHunted()
        {
            Console.WriteLine("I hunt..I am a predetor");
        }
    }
}
