﻿using System;
using System.Threading.Tasks;

namespace DuplicateCode
{
    class DuplicateCode
    {

        public static void Main(string[] args)
        {
            string[] tasksIndividual = new string[0], tasksWork = new string[0], tasksFamilly = new string[0];

            while (true)
            {
                Console.Clear();

                //this line initialize arrays to hold tasks
                int max = tasksIndividual.Length > tasksWork.Length ? tasksIndividual.Length : tasksWork.Length;

                //decides maximum height of the table 
                max = max > tasksFamilly.Length ? max : tasksFamilly.Length;

                //this prints the column names of the table 
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine(new string(' ', 12) + "CATEGORIES");
                Console.WriteLine(new string(' ', 10) + new string('-', 94));
                Console.WriteLine("{0,10}|{1,30}|{2,30}|{3,30}|", "item #", "Personal", "Work", "Family");
                Console.WriteLine(new string(' ', 10) + new string('-', 94));
                for (int i = 0; i < max; i++)
                {
                    Console.Write("{0,10}|", i);

                    //this prints tasks
                    printTasks(tasksIndividual, i);
                    printTasks(tasksWork, i);
                    printTasks(tasksFamilly, i);

                    Console.WriteLine();
                }

                Console.ResetColor();

                //this part asks questions from the user to enter tasks
                Console.WriteLine("\nWhich category do you want to place a new task? Type \'Personal\', \'Work\', or \'Family\'");
                Console.Write(">> ");
                string listName = Console.ReadLine().ToLower();
                Console.WriteLine("Describe your task below (max. 30 symbols).");
                Console.Write(">> ");
                string task = Console.ReadLine();

                if (task.Length > 30) task = task.Substring(0, 30);

                //this part updates arrays which hold tasks
                if (listName == "personal")
                {
                    tasksIndividual = updateTasksLists(tasksIndividual, task);
                }
                else if (listName == "work")
                {
                    tasksWork = updateTasksLists(tasksWork, task);
                }
                else if (listName == "family")
                {
                    tasksFamilly = updateTasksLists(tasksFamilly, task);
                }
            }
        }

        //this method prints the table values
        public static void printTasks(string[] tasksType, int index)
        {
            if (tasksType.Length > index)
            {
                Console.Write("{0,30}|", tasksType[index]);
            }
            else
            {
                Console.Write("{0,30}|", "N/A");
            }
        }

        //this method updates an array which hold tasks when task list and new task is given
        public static string[] updateTasksLists(string[] tasksList, String newTask)
        {
            string[] goalsIndividualNew = null;
            goalsIndividualNew = new string[tasksList.Length + 1];
            for (int j = 0; j < tasksList.Length; j++)
            {
                goalsIndividualNew[j] = tasksList[j];
            }
            goalsIndividualNew[goalsIndividualNew.Length - 1] = newTask;
            return goalsIndividualNew;
        }

    }
}
