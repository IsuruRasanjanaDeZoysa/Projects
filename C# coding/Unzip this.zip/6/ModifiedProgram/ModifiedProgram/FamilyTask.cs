﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModifiedProgram
{
    public class FamilyTask:Task
    {
        public FamilyTask(String task) : base(task) { }
        public FamilyTask(String task, String priority) : base(task, priority) { }
        public FamilyTask(String task, String priority, String dueDate_) : base(task, priority, dueDate_) { }
        public FamilyTask(String task, String priority, String dueDate_, bool important_) : base(task, priority, dueDate_, important_) { }
    }
}
