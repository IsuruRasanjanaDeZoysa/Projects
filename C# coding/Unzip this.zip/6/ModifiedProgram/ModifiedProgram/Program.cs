﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ModifiedProgram
{
    public class Program
    {
        static void Main(string[] args)
        {
            //this line initialize lists
            List<Task> tasksIndividual = new List<Task>();
            List<Task> tasksWork = new List<Task>();
            List<Task> tasksFamily = new List<Task>();


            List<List<Task>> new_categories= new List<List<Task>>();
            int length_of_new_categories = 0;
            List<String> newCategories_names = new List<String>();

            while (true)
            {
                Console.Clear();
                int max = tasksIndividual.Count > tasksWork.Count ? tasksIndividual.Count : tasksWork.Count;
                max = max > tasksFamily.Count ? max : tasksFamily.Count;

                for(int i = 0; i < length_of_new_categories; i++)
                {
                    if (new_categories[i].Count>max) max= new_categories[i].Count;
                }

                //these lines sort tasks according to the priority
                tasksIndividual = Prioratize(tasksIndividual);
                tasksWork = Prioratize(tasksWork);
                tasksFamily = Prioratize(tasksFamily);
                for (int i = 0; i < length_of_new_categories; i++)
                {
                    new_categories[i] = Prioratize(new_categories[i]);
                }

                //change the forground color to print the table in blue and print table names and column names
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine(new string(' ', 12) + "CATEGORIES");
                Console.WriteLine(new string(' ', 10) + new string('-', 110));
                Console.WriteLine("{0,8}|{1,35}|{2,35}|{3,35}|", "item #", "Personal", "Work", "Family");
                Console.WriteLine(new string(' ', 10) + new string('-', 110));

                

                for (int i = 0; i < max; i++)
                {                    
                    Console.Write("{0,8}|", i);
                    PrintMethod(tasksIndividual, i);
                    PrintMethod(tasksWork, i);
                    PrintMethod(tasksFamily, i);
                    Console.WriteLine();
                }

                for(int i = 0; i < length_of_new_categories; i++)
                {
                    Console.WriteLine(new string(' ', 10) + new string('-', 50));
                    Console.WriteLine("{0,8}|{1,35}|", "item #", newCategories_names[i]);
                    Console.WriteLine(new string(' ', 10) + new string('-', 50));

                    for (int k = 0; k < max; k++)
                    {
                        PrintMethod(new_categories[i], k);
                        Console.WriteLine();
                    }

                }
                
                Console.ResetColor();

                //this is the menu
                Console.WriteLine("Menu");
                Console.WriteLine("");

                Console.WriteLine("Enter 1 to place a new task ");
                Console.WriteLine("Enter 2 to delete an existing category ");
                Console.WriteLine("Enter 3 to add an category ");
                Console.WriteLine("Enter 4 to delete a task ");
                Console.WriteLine("Enter 5 to change priority of a task ");
                Console.WriteLine("Enter 6 to move a task from one category to another ");
                Console.WriteLine("Enter 7 to highlight a task Enter 7");

                string option = Console.ReadLine();

                //add new task option
                if (option == "1")
                {
                    Console.WriteLine("\nWhich category do you want to place a new task? ");
                    Console.Write(">> ");
                    string list_name = Console.ReadLine().ToLower();
                    Console.WriteLine("Describe your task below (max. 30 symbols).");
                    Console.Write(">> ");
                    string task = Console.ReadLine();
                    Console.WriteLine("What is the due date? ");
                    Console.Write(">> ");
                    string dueDate_ = Console.ReadLine();
                    Console.WriteLine("What is the priority? Type \'m\',\'h\'");
                    Console.Write(">> ");
                    string priority_ = Console.ReadLine();

                    if (task.Length > 30) task = task.Substring(0, 30);

                    if (list_name == "personal")
                    {
                        tasksIndividual.Add(new PersonalTask(task,priority_,dueDate_));
                    }
                    else if (list_name == "work")
                    {
                        tasksWork.Add(new WorkTask(task, priority_, dueDate_));
                    }
                    else if (list_name == "family")
                    {
                        tasksFamily.Add(new FamilyTask(task, priority_, dueDate_));
                    }
                    else if (newCategories_names.Contains(list_name))
                    {
                        int index= newCategories_names.IndexOf(list_name);
                        new_categories[index].Add(new Task(task, priority_, dueDate_));
                    }
                    
                }
                //delete category option
                if (option == "2")
                {
                    Console.WriteLine("\nWhat is the category do you want to delete? Type \'Personal\', \'Work\', or \'Family\'");
                    Console.Write(">> ");
                    string listName = Console.ReadLine().ToLower();
                    if (listName == "personal")
                    {
                        tasksIndividual.Clear();
                    }
                    else if (listName == "work")
                    {
                        tasksWork.Clear();
                    }
                    else if (listName == "family")
                    {
                        tasksFamily.Clear();
                    }
                    else if (newCategories_names.Contains(listName))
                    {
                        int index = newCategories_names.IndexOf(listName);
                        new_categories.RemoveAt(index);
                        length_of_new_categories = 1;
                    }

                }
                //add new category option
                if (option == "3")
                {
                    length_of_new_categories += 1;
                    Console.WriteLine("\nEnter category name you need to add?");
                    Console.Write(">> ");
                    string categoryName = Console.ReadLine().ToLower();
                    newCategories_names.Add(categoryName);
                    new_categories.Add(new List<Task>());                   

                }
                //delete task option
                if (option == "4")
                {
                    Console.WriteLine("\nWhat is the task do you want to delete?");
                    Console.Write(">> ");
                    string taskName = Console.ReadLine().ToLower();                    

                    DeleteTask(tasksIndividual, taskName);
                    DeleteTask(tasksWork, taskName);
                    DeleteTask(tasksFamily, taskName);
                    for (int i = 0; i < length_of_new_categories; i++)
                    {
                        DeleteTask(new_categories[i],taskName);
                    }
                   
                }
                //change task's priority option
                if (option == "5")
                {
                    Console.WriteLine("\nWhich task's priority do you want to change?");
                    Console.Write(">> ");
                    string taskName = Console.ReadLine().ToLower();
                    Console.WriteLine("\nWhat should be the priority?");
                    Console.Write(">> ");
                    string priority= Console.ReadLine().ToLower();

                    //assumption-a task could be in multiple categories
                    ChangePriority(tasksIndividual, taskName, priority);
                    ChangePriority(tasksWork, taskName, priority);
                    ChangePriority(tasksFamily, taskName, priority);

                    for (int i = 0; i < length_of_new_categories; i++)
                    {
                        ChangePriority(new_categories[i], taskName,priority);
                    }
                }
                //change task's category option
                if (option == "6")
                {
                    Console.WriteLine("\nWhat is the task you want to change the category?");
                    Console.Write(">> ");
                    string taskName = Console.ReadLine().ToLower();

                    Console.WriteLine("\nWhat should be the new category?");
                    Console.Write(">> ");
                    string newCategory = Console.ReadLine().ToLower();

                    Console.WriteLine("\nEnter new due date?");
                    Console.Write(">> ");
                    string dueDate_ = Console.ReadLine().ToLower();

                    Console.WriteLine("\nEnter new priority?");
                    Console.Write(">> ");
                    string priority_ = Console.ReadLine().ToLower();


                    //complete these
                    DeleteTask(tasksIndividual, taskName);
                    DeleteTask(tasksWork, taskName);
                    DeleteTask(tasksFamily, taskName);
                    for (int i = 0; i < length_of_new_categories; i++)
                    {
                        DeleteTask(new_categories[i], taskName);
                    }


                    if (newCategory == "personal")
                    {
                        tasksIndividual.Add(new PersonalTask(taskName,priority_,dueDate_));
                    }
                    else if (newCategory == "work")
                    {
                        tasksWork.Add(new WorkTask(taskName, priority_, dueDate_));
                    }
                    else if (newCategory == "family")
                    {
                        tasksFamily.Add(new FamilyTask(taskName, priority_, dueDate_));
                    }
                    else if (newCategories_names.Contains(newCategory))
                    {
                        int index = newCategories_names.IndexOf(newCategory);
                        new_categories[index].Add(new Task(taskName, priority_, dueDate_));
                    }


                }
                if(option == "7")
                {
                    Console.WriteLine("\nWhat task should be hightlighted?");
                    Console.Write(">> ");
                    string taskName = Console.ReadLine().ToLower();
                    HighlightTask(tasksIndividual,taskName);
                    HighlightTask(tasksWork, taskName);
                    HighlightTask(tasksFamily, taskName);
                    for (int i = 0; i < length_of_new_categories; i++)
                    {
                        HighlightTask(new_categories[i], taskName);
                    }
                }

                
            }

        }

        //this method delete a task from the table
        public static void DeleteTask(List<Task> task_list, String task_name)
        {
            for (int i = 0; i < task_list.Count; i++)
            {
                if (task_list[i].task_name == task_name)
                {
                    task_list.RemoveAt(i);
                }
            }
        }


        //this method call Print method of a given task object
        public static void PrintMethod(List<Task> task_list,int index)
        {
            if (task_list.Count > index)
            {
                task_list[index].PrintTask(task_list.Count > index);
            }
            else
            {
                Console.Write("{0,35}|", "N/A");
            }
        }

        

        //this change the priority of a given task
        public static void ChangePriority(List<Task> task_list, String task_name,String priority)
        {
            for (int i = 0; i < task_list.Count; i++)
            {
                if (task_list[i].task_name == task_name)
                {
                    task_list[i].prioriy = priority;
                }
            }
        }

        //this method highlight a given task
        public static void HighlightTask(List<Task> task_ist, String task_name)
        {
            foreach (Task task in task_ist)
            {
                if (task.task_name == task_name)
                {
                    task.important = true;
                }
            }
        }


        //this method remake a task list according to the priority
        public static List<Task> Prioratize(List<Task> task_list)
        {
            List<Task> list = new List<Task>();
            foreach (Task task in task_list)
            {
                if (task.prioriy == "h")
                {
                    list.Add(task);
                }
            }
            foreach (Task task in task_list)
            {
                if (task.prioriy == "m")
                {
                    list.Add(task);
                }
            }            
            foreach (Task task in task_list)
            {
                if (task.prioriy != "m" && task.prioriy!="h")
                {
                    list.Add(task);
                }
            }
            return list;
        }
        
        
    }
}
