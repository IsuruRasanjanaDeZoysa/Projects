﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ModifiedProgram
{
    public class Task
    {
        public String task_name;
        public String due_date;
        public String prioriy;
        public bool important;

        public Task(String taskName_)
        {
            task_name = taskName_;
            prioriy = "medium";
        }
        public Task(String taskName_,String priority_)
        {
            this.task_name = taskName_;
            this.prioriy = priority_;
        }

        public Task(String taskName_, String priority_,String dueDate_)
        {
            this.task_name = taskName_;
            this.prioriy = priority_;
            this.due_date = dueDate_;
        }

        public Task(String taskName_, String priority_, String dueDate_,bool important_)
        {
            this.task_name = taskName_;
            this.prioriy = priority_;
            this.due_date = dueDate_;
            this.important = important_;
        }

        public void PrintTask(Boolean condition)
        {
            if(condition)
            {
                if (important)
                {
                    Console.BackgroundColor = ConsoleColor.Red;
                    Console.Write("{0,35}|", task_name + " "+ due_date);
                    Console.BackgroundColor = ConsoleColor.Black;
                }
                else
                {
                    Console.Write("{0,35}|", task_name + " "+ due_date);
                }
                
            }
        }

    }
}
