﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModifiedProgram
{
    public class PersonalTask:Task
    {
        public PersonalTask(String task) : base(task) { }
        public PersonalTask(String task,String priority): base(task,priority) { }
        public PersonalTask(String task, String priority, String dueDate_) : base(task, priority,dueDate_) { }
        public PersonalTask(String task, String priority, String dueDate_, bool important_) : base(task, priority, dueDate_, important_) { }
    }
}
