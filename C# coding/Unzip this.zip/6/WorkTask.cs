﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModifiedProgram
{
    public class WorkTask:Task
    {
        public WorkTask(String task) : base(task) { }
        public WorkTask(String task, String priority) : base(task, priority) { }
        public WorkTask(String task, String priority, String dueDate_) : base(task, priority, dueDate_) { }
    }
}
