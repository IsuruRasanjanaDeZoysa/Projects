﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ModifiedProgram
{
    public class Task
    {
        public String taskName;
        public String dueDate;
        public String prioriy;
        public bool important;

        public Task(String taskName_)
        {
            taskName = taskName_;
            prioriy = "medium";
        }
        public Task(String taskName_,String priority_)
        {
            this.taskName = taskName_;
            this.prioriy = priority_;
        }

        public Task(String taskName_, String priority_,String dueDate_)
        {
            this.taskName = taskName_;
            this.prioriy = priority_;
            this.dueDate = dueDate_;
        }
        public void PrintTask(Boolean condition)
        {
            if(condition)
            {
                if (important)
                {
                    Console.BackgroundColor = ConsoleColor.Red;
                    Console.Write("{0,35}|", taskName+" "+dueDate);
                    Console.BackgroundColor = ConsoleColor.Black;
                }
                else
                {
                    Console.Write("{0,35}|", taskName+" "+dueDate);
                }
                
            }
        }

    }
}
