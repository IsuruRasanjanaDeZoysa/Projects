﻿using System;

namespace project_bank
{
    public class Account
    {
        private String _name; // Account holder's name
        private decimal _balance;

        //Constructor now requires an account holder's name and initial balance
        public Account(String name, decimal initialbalance)
        {
            _name = name;
            _balance = initialbalance;
        }

        //Property (read-only)
        public String Name
        {
            get
            {
                return _name;
            }
        }
        public decimal Balance
        {
            get
            {
                return _balance;
            }
        }
        //Methods
        public bool Deposit(decimal amount)
        {
            if (amount > 0)
            {
                _balance += amount;
                return true;
            }
            return false;
        }

        public bool Withdraw(decimal amount)
        {
            if (amount > 0 && _balance >= amount)
            {
                _balance -= amount;
                return true;
            }
            return false;
        }
        
        // Print method now also displays the account holder's name
        public void Print(){
            Console.WriteLine($"{_name}'s Current balance: {_balance:C}");
        }

    }

}