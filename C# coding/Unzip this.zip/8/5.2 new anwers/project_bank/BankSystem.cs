﻿using System;
// using System.Diagnostics;
namespace project_bank
{
    enum MenuOption
    {
        Withdraw = 1,
        Deposit,
        Transfer,
        Print,
        Quit
    }

    class BankSystem
    {
        static MenuOption ReadUserOption()
        {
            int userChoice;
            do
            {
                Console.WriteLine("\nMenu\n1. Withdraw\n2. Deposit\n3. Transfer\n4. Print\n5. Quit");
                userChoice = Convert.ToInt32(Console.ReadLine());

            } while (userChoice < 1 || userChoice > 5);

            return (MenuOption)userChoice;
        }

        static void DoDeposit(Account account)          //Deposits money into account
        {
            Console.WriteLine("Enter amount to deposit: ");
            decimal amount = Convert.ToDecimal(Console.ReadLine());

            try
            {
                DepositTransaction deposit = new DepositTransaction(account, amount);
                deposit.Execute();
                deposit.Print();
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine("Deposit failed: " + ex.Message); // Print exception message
            }
        }

        static void DoWithdraw(Account account)         //Withdraws money from account
        {
            Console.WriteLine("Enter amount to withdraw: ");
            decimal amount = Convert.ToDecimal(Console.ReadLine());

            try
            {
                WithdrawTransaction withdraw = new WithdrawTransaction(account, amount);
                withdraw.Execute();
                withdraw.Print();
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine("Withdrawal failed: " + ex.Message); // Print exception message
            }
        }

        static void DoTransfer(Account fromAccount, Account toAccount)      //Transfers money from one account to another
        {
            Console.WriteLine("Enter amount to transfer: ");
            decimal amount = Convert.ToDecimal(Console.ReadLine());

            try
            {
                TransferTransaction transfer = new TransferTransaction(fromAccount, toAccount, amount);
                transfer.Execute();
                transfer.Print();
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine("Transfer Unsuccessful : " + ex.Message); // Print exception message
            }
        }

        static void DoPrint(Account account)            //Prints account details
        {
            account.Print();
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Please enter the account holder's name:");
            string accountName = Console.ReadLine();

            // Initialize account with the entered name and 0 balance
            Account account = new Account(accountName, 0);

            // Already created accounts for transactios
            Account michael = new Account("Michael Klein", 1000);
            Account shannon = new Account("Shannon", 2500);
            Account caroline = new Account("Caroline", 4000);
            Account derek = new Account("Derek", 500);

            //Available balances of all accounts of the banking system
            Console.WriteLine();
            account.Print();
            michael.Print();
            shannon.Print();
            caroline.Print();
            derek.Print();

            // // Testing and Debugging
            // Debug.Assert(account.Balance == 0, "Account Balance should be 0"); // Check initial balance of account
            // Debug.Assert(michael.Balance == 1000, "Balance should be 1000"); // Check initial balance of michael

            // // Test deposit success and rollback
            // DepositTransaction new_dep = new DepositTransaction(account, 500);

            // new_dep.Print();
            // new_dep.Execute();
            // Debug.Assert(account.Balance == 500, "Balance should be 500 after deposit");
            // Debug.Assert(new_dep.Executed == true, "dep.Executed should be true after successful execution");
            // Debug.Assert(new_dep.Success == true, "dep.Success should be true after successful execution");
            // new_dep.Print();

            // new_dep.Rollback();
            // Debug.Assert(account.Balance == 0, "Balance should be 0 after rollback");
            // Debug.Assert(new_dep.Reversed == true, "dep.Reversed should be true after rollback");
            // new_dep.Print();

            MenuOption userSelection;

            do
            {
                userSelection = ReadUserOption();

                switch (userSelection)
                {
                    case MenuOption.Withdraw:
                        DoWithdraw(account);
                        break;
                    case MenuOption.Deposit:
                        DoDeposit(account);
                        break;
                    case MenuOption.Transfer:
                        DoTransfer(account, michael);
                        break;
                    case MenuOption.Print:
                        DoPrint(account);
                        break;
                    case MenuOption.Quit:
                        Console.WriteLine("Quitting....");
                        break;
                }
            } while (userSelection != MenuOption.Quit);
        }

    }
}