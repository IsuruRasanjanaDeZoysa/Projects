﻿using System;

namespace project_bank
{
    class TransferTransaction
    {
        private Account _fromAccount;
        private Account _toAccount;
        private decimal _amount;
        DepositTransaction _deposit;
        WithdrawTransaction _withdraw;
        private bool _executed;
        private bool _reversed;
        private bool _success;

        //Constructor
        public TransferTransaction(Account fromAccount, Account toAccount, decimal amount)
        {
            _fromAccount = fromAccount;
            _toAccount = toAccount;
            _amount = amount;
            _withdraw = new WithdrawTransaction(_fromAccount, _amount);
            _deposit = new DepositTransaction(_toAccount, _amount);
        }

        //Properties (read-only)
        public bool Executed
        {
            get
            {
                return _executed;
            }
        }

        public bool Reversed
        {
            get
            {
                return _reversed;
            }
        }

        public bool Success
        {
            get
            {
                return _success;
            }
        }

        public void Print()
        {
            if (_success)
            {
                Console.WriteLine("Transaction details: ");
                Console.WriteLine("**************************");
                Console.WriteLine("Transferred {0} from {1} ({2})'s account to {3} ({4})'s account",
                        _amount.ToString("C"), _fromAccount.Name, _fromAccount.Balance.ToString("C"), _toAccount.Name, _toAccount.Balance.ToString("C"));
            }
            else
            {
                Console.WriteLine("Sender Account Balance: " + _fromAccount.Balance.ToString("C"));
                Console.WriteLine("Recipient Account Balance: " + _toAccount.Balance.ToString("C"));

                Console.WriteLine("Withdrawal details:");
                _withdraw.Print();
                Console.WriteLine("Deposit details:");
                _deposit.Print();
            }
        }

        public void RollbackPrint()
        {
            Console.WriteLine("Transaction details: ");
            Console.WriteLine("**************************");
            Console.WriteLine("Rollback done: {0} returned from {1}'s into {2}'s account", _amount.ToString("C"), _toAccount.Name, _fromAccount.Name);
            Console.WriteLine("{0}'s Account Balance: {1}", _fromAccount.Name, _fromAccount.Balance.ToString("C"));
            Console.WriteLine("{0}'s Account Balance: {1}", _toAccount.Name, _toAccount.Balance.ToString("C"));
        }

        public void Execute()
        {
            if (_executed)
            {
                throw new InvalidOperationException("Transfer already executed");
            }
            _executed = true;

            _withdraw.Execute();

            //Ensure withdrawal is successful, only then attempt deposit
            if (_withdraw.Success)
            {
                try
                {
                    _deposit.Execute();
                }
                catch (InvalidOperationException)
                {
                    Console.WriteLine("Transaction unsuccessful");
                    //If deposit unsuccessful, attempt rollback to sender account
                    try
                    {
                        _withdraw.Rollback();
                    }
                    catch (InvalidOperationException)
                    {
                        Console.WriteLine("Rollback unsuccessful");
                    }
                }
            }
        }

        public void Rollback()
        {
            if (_reversed)
            {
                throw new InvalidOperationException("Rollback already executed");
            }
            else if (!_withdraw.Success && !_deposit.Success)
            {
                throw new InvalidOperationException("Transfer was not successfully executed");
            }
            else
            {
                _deposit.Rollback();

                //First withdraw from recipient account, then deposit back to sender account
                if (_deposit.Reversed)
                {
                    try
                    {
                        _withdraw.Rollback();
                    }
                    catch (InvalidOperationException)
                    {
                        Console.WriteLine("Rollback unsuccessful");
                    }
                }
            }
            _reversed = true;
            _success = false; // Update success after rollback
        }
    }
}