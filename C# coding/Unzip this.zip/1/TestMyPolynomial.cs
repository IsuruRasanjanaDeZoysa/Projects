﻿
class TestMyPolynomial
{
    public static void Main(string[] args)
    {
        double[] myArray = new double[] { 1.0, 2.0, 3.0, 4.0 };
        MyPolynomial firstPolynomial = new MyPolynomial(myArray);
        //result of the below line should be 3
        Console.WriteLine(firstPolynomial.GetDegree());
        //result of the below line should be 4x^3 + 3x^2 + 2x^1 + 1
        Console.WriteLine(firstPolynomial.ToString());
        //result of the below line should be 49
        Console.WriteLine(firstPolynomial.Evaluate(2));

        MyPolynomial secondPolynomial = new MyPolynomial(myArray);
        //result of the below line should be  8x^3 + 6x^2 + 4x^1 + 2
        Console.WriteLine(secondPolynomial.Add(secondPolynomial).ToString());
        //result of the below line should be 16x^6 + 24x^5 + 25x^4 + 20x^3 + 10x^2 + 4x^1 + 1
        Console.WriteLine(secondPolynomial.Multiply(secondPolynomial).ToString());
    }
}