﻿using System;
using System.Text;
using System.Collections.Generic;

class MyPolynomial
{
    //this variable stores the coefficients of the polynomial
    public double[] _coeffs;

    public MyPolynomial(double[] coeffs)
    {

        _coeffs = coeffs;
    }
    //this method returns the degree of the polynomial
    public int GetDegree()
    {
        int degree = _coeffs.Length - 1;
        return degree;
    }
    //this method returns the viewable representation of the polynomial
    public override string ToString()
    {

        string polynomial = "";

        for (int i = _coeffs.Length - 1; i >= 0; i--)
        {

            if (_coeffs[i] != 0)
            {

                if (polynomial.Length > 0)
                {

                    polynomial += " + ";
                }

                polynomial += _coeffs[i].ToString();

                if (i > 0)
                {
                    polynomial += $"x^{i}";

                }
            }
        }

        return polynomial;
    }
    //this method evaluate the value of the polynomial when a value for x is given
    public double Evaluate(double x)
    {

        double result = 0;

        for (int i = 0; i < _coeffs.Length; i++)
        {
            result += _coeffs[i] * Math.Pow(x, i);
        }

        return result;
    }
    //this method returns the coefficients of the addition of two polynomials
    public MyPolynomial Add(MyPolynomial another)
    {
        int finalSize = Math.Max(_coeffs.Length, another._coeffs.Length);
        List<double> finalCoeffs = new List<double>();
        double[] arrayWithHigherLength = (_coeffs.Length > another._coeffs.Length) ? _coeffs : another._coeffs;
        double[] arrayWithLowerLength = (_coeffs.Length < another._coeffs.Length) ? _coeffs : another._coeffs;
        if (_coeffs.Length != another._coeffs.Length)
        {


            int difference = Math.Abs(_coeffs.Length - another._coeffs.Length);


            for (int i = 0; i < finalSize; i++)
            {
                if (i <= difference - 1)
                {
                    finalCoeffs.Add(arrayWithHigherLength[i]);
                }
                else
                {
                    finalCoeffs.Add(arrayWithHigherLength[i] + arrayWithLowerLength[i]);
                }
            }

        }
        else
        {
            for (int i = 0; i < finalSize; i++)
            {
                finalCoeffs.Add(arrayWithHigherLength[i] + arrayWithLowerLength[i]);
            }
        }
        double[] _finalCoeffs = finalCoeffs.ToArray();
        this._coeffs = finalCoeffs;
        return this;
    }
    //this method returns the coefficients of the multiplication of two polynomials
    public MyPolynomial Multiply(MyPolynomial another)
    {

        int finalDegree = GetDegree() + another.GetDegree();
        double[] finalCoeffs = new double[finalDegree + 1];

        for (int i = 0; i < _coeffs.Length; i++)
        {
            for (int j = 0; j < another._coeffs.Length; j++)
            {
                finalCoeffs[i + j] += _coeffs[i] * another._coeffs[j];
            }
        }
        this._coeffs = finalCoeffs;
        return this;
    }
}
