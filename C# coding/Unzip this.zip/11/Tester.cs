﻿using System;

namespace SimpleReactionMachine
{
    class Tester
    {
        private static IController controller;
        private static IGui gui;
        private static string displayText;
        private static int randomNumber;
        private static int passed = 0;

        static void Main(string[] args)
        {
            // run simple test
            SimpleTest();
            Console.WriteLine("\n=====================================\nSummary: {0} tests passed out of 64", passed);
            Console.ReadKey();
        }

        private static void SimpleTest()
        {
            //Construct a ReactionController
            controller = new EnhancedReactionController();
            gui = new DummyGui();

            //Connect them to each other
            gui.Connect(controller);
            controller.Connect(gui, new RndGenerator());

            //Reset the components()
            gui.Init();

            //Test the SimpleReactionController
            //IDLE
            DoReset('A', controller, "Insert coin");
            DoGoStop('B', controller, "Insert coin");
            DoTicks('C', controller, 1, "Insert coin");

            //coinInserted
            DoInsertCoin('D', controller, "Press GO!");

            //READY
            DoTicks('E', controller, 1, "Press GO!");
            DoInsertCoin('F', controller, "Press GO!");

            //goStop
            randomNumber = 117;
            DoGoStop('G', controller, "Wait...");

            //since this is the first round count should be 1
            CheckCount('H', (EnhancedReactionController)controller, 1);

            //WAIT tick(s)
            DoTicks('I', controller, randomNumber - 1, "Wait...");
            
            //RUN tick(s)
            //just after end of ticks for Waiting period 0.00 should be displayed 
            DoTicks('J', controller, 1, "0.00");
            DoTicks('K', controller, 1, "0.01");
            DoTicks('L', controller, 11, "0.12");
            DoTicks('M', controller, 111, "1.23");

            //goStop
            DoGoStop('N', controller, "1.23");

            //STOP tick(s)
            DoTicks('O', controller, 299, "1.23");

            //if player press Go/Stop button during waiting period game should be aborted
            DoTicks('P', controller, 1, "Wait...");    //after one round there should be another round to check reaction time         
            CheckCount('Q', (EnhancedReactionController)controller, 2);   //count should be 2
            DoGoStop('R', controller, "Insert coin");
            CheckCount('S', (EnhancedReactionController)controller, 0);  //count should be 0


            //here i check for completion of 3 rounds
            DoInsertCoin('T', controller, "Press GO!");
            randomNumber = 167;
            DoGoStop('U', controller, "Wait...");
            CheckCount('V', (EnhancedReactionController)controller, 1);
            DoTicks('W', controller, randomNumber, "0.00");
            DoTicks('X', controller, 152, "1.52");
            DoGoStop('Y', controller, "1.52");
            DoTicks('Z', controller, 100, "1.52");

            randomNumber = 145;
            DoGoStop('a', controller, "Wait...");
            CheckCount('b', (EnhancedReactionController)controller, 2);
            DoTicks('c', controller, randomNumber - 1, "Wait...");
            DoTicks('d', controller, 1, "0.00");
            DoTicks('e', controller, 145, "1.45");
            DoGoStop('f', controller,"1.45");

            randomNumber = 200;
            DoTicks('g', controller, 300, "Wait...");    //reaction time should be displayed 3 secs
            CheckCount('h', (EnhancedReactionController)controller, 3);
            DoTicks('i', controller, 200, "0.00");
            DoTicks('j', controller, 120, "1.20");
            DoGoStop('k', controller, "1.20");
            DoTicks('l', controller,10, "1.20");
            DoGoStop('m', controller, "Average = 1.39");   //when GoStop is pressed after 3 rounds anthor coin should be inserted
            DoGoStop('n', controller, "Insert coin");//when player press Go/Stop button during displaying average time game is immediately over (here i assumed game over and game aborted means another coin should be inserted)


            //user should press goStop before 10 seconds ends after coin insertion unless another coin should be inserted
            DoInsertCoin('o', controller, "Press GO!");
            DoTicks('p', controller, 1000, "Insert Coin");

            //without skipping waiting periods and random delay times
            DoInsertCoin('q', controller, "Press GO!");
            randomNumber = 167;
            DoGoStop('r', controller, "Wait...");
            CheckCount('s', (EnhancedReactionController)controller, 1);
            DoTicks('t', controller, randomNumber, "0.00");
            DoTicks('u', controller, 125, "1.25");
            DoGoStop('v', controller, "1.25");
            DoTicks('w', controller, 100, "1.25");
            randomNumber = 145;
            DoGoStop('x', controller, "Wait...");
            CheckCount('y', (EnhancedReactionController)controller, 2);
            DoTicks('z', controller, randomNumber - 1, "Wait...");
            DoTicks('0', controller, 1, "0.00");
            DoTicks('1', controller, 125, "1.25");
            DoGoStop('2', controller, "1.25");
            randomNumber = 200;
            DoTicks('3', controller, 300, "Wait...");    //reaction time should be displayed 3 secs
            CheckCount('4', (EnhancedReactionController)controller, 3);
            DoTicks('5', controller, 200, "0.00");
            DoTicks('6', controller, 125, "1.25");
            DoGoStop('7', controller, "1.25");
            DoTicks('8', controller, 10, "1.25"); //check for the average value
            DoTicks('9', controller, 290, "Average = 1.25");
            DoTicks('#', controller, 100, "Average = 1.25");
            DoTicks('$', controller, 400, "Insert coin");    


            

        }

        public static void CheckCount(char ch, EnhancedReactionController controller,int i)
        {
            if (i == controller.Count())
            {
                    Console.WriteLine("test {0}: passed successfully", ch);
                    passed++;
            }
            else
            {
                Console.WriteLine("test {0}: failed with message ( expected {1} | received {2})", ch, i, controller.Count());
            }
                    
        }
        private static void DoReset(char ch, IController controller, string msg)
        {
            try
            {
                controller.Init();
                GetMessage(ch, msg);
            }
            catch (Exception exception)
            {
                Console.WriteLine("test {0}: failed with exception {1})", ch, msg, exception.Message);
            }
        }

        private static void DoGoStop(char ch, IController controller, string msg)
        {
            try
            {
                controller.GoStopPressed();
                GetMessage(ch, msg);
            }
            catch (Exception exception)
            {
                Console.WriteLine("test {0}: failed with exception {1})", ch, msg, exception.Message);
            }
        }

        private static void DoInsertCoin(char ch, IController controller, string msg)
        {
            try
            {
                controller.CoinInserted();
                GetMessage(ch, msg);
            }
            catch (Exception exception)
            {
                Console.WriteLine("test {0}: failed with exception {1})", ch, msg, exception.Message);
            }
        }

        private static void DoTicks(char ch, IController controller, int n, string msg)
        {
            try
            {
                for (int t = 0; t < n; t++) controller.Tick();
                GetMessage(ch, msg);
            }
            catch (Exception exception)
            {
                Console.WriteLine("test {0}: failed with exception {1})", ch, msg, exception.Message);
            }
        }

        private static void GetMessage(char ch, string msg)
        {
            if (msg.ToLower() == displayText.ToLower())
            {
                Console.WriteLine("test {0}: passed successfully", ch);
                passed++;
            }
            else
                Console.WriteLine("test {0}: failed with message ( expected {1} | received {2})", ch, msg, displayText);
        }

        private class DummyGui : IGui
        {

            private IController controller;

            public void Connect(IController controller)
            {
                this.controller = controller;
            }

            public void Init()
            {
                displayText = "?reset?";
            }

            public void SetDisplay(string msg)
            {
                displayText = msg;
            }
        }

        private class RndGenerator : IRandom
        {
            public int GetRandom(int from, int to)
            {
                return randomNumber;
            }
        }

    }

}
