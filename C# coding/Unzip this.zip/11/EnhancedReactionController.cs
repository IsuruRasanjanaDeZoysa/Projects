﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleReactionMachine
{
    public class EnhancedReactionController : IController
    {
        private static IGui _gui;
        private static IRandom _rng;
        private static State state;
        private static int timer;
        private static string numberToDisplay;
        private static int count;
        private static double sum;

        public int Count()
        {
             return count; 
        }
        public void Connect(IGui gui, IRandom rng)
        {
            _gui = gui;
            _rng = rng;
            Init();
        }

        //Called to initialise the controller
        public void Init()
        {
            state = new WaitForCoinState();

        }

        //Called whenever a coin is inserted into the machine
        public void CoinInserted()
        {
            state.pressInsertCoin();
        }

        //Called whenever the go/stop button is pressed
        public void GoStopPressed()
        {
            state.pressGoStop();

        }

        //Called to deliver a TICK to the controller
        public void Tick()
        {
            state.tick();
        }

        //this is the abstract class used to 
        public interface State
        {
            public abstract void pressInsertCoin();
            public abstract void pressGoStop();
            public abstract void tick();
        }

        //this class represents the state which reaction machine waits for a coin insertion
        private class WaitForCoinState: State
        {
            public WaitForCoinState()
            {
                count = 0;
                sum = 0;
                _gui.SetDisplay("Insert coin");
                
            }
            public override void pressInsertCoin()
            {
                state=new WaitingForPressGoState();
            }
            public override void pressGoStop()
            {
                
            }

            public override void tick()
            {
                
            }
        }

        //this class represents the state which reaction machine waits for  Go/Stop button to be pressed
        private class WaitingForPressGoState : State
        {
            public WaitingForPressGoState()
            {
                _gui.SetDisplay("Press Go!");
                timer = 1000;

            }

            public override void pressInsertCoin()
            {

            }

            public override void pressGoStop()
            {
                state = new WaitState();
            }

            public override void tick()
            {
                timer--;
                if (timer == 0)
                {
                    state = new WaitForCoinState();
                }
            }
        }

        //this class represents the state which reaction machine waits for randome amount of time
        private class WaitState : State
        {
            public WaitState()
            {
                count++;
                _gui.SetDisplay("Wait...");
                timer = _rng.GetRandom(100, 250);

            }
            public override void pressInsertCoin()
            {

            }
            public override void pressGoStop()
            {

                state = new WaitForCoinState();
                count = 0;
            }

            public override void tick()
            {

                timer--;
                if (timer == 0)
                {
                    _gui.SetDisplay("0.00");
                    state = new StartedState();
                }
            }
        }

        //this class represents the state which reaction machine waits for  Go/Stop button to be pressed
        private class StartedState : State
        {
            public StartedState()
            {
                timer = 200;
            }
            public override void pressInsertCoin()
            {

            }
            public override void pressGoStop()
            {
                state = new DisplayFinalTimeState();

            }

            public override void tick()
            {
                timer--;
                if (timer >= 0)  //**
                {
                    numberToDisplay = ((200 - timer) / 100.0).ToString("0.00");
                    _gui.SetDisplay(numberToDisplay);
                    //sum += Double.Parse(numberToDisplay);
                }
                else
                {
                    state = new DisplayFinalTimeState();
                }
            }
        }

        //this class represents the state which reaction machine display the reaction time/final displayed time
        private class DisplayFinalTimeState : State
        {
            public DisplayFinalTimeState()
            {

                _gui.SetDisplay(numberToDisplay);
                timer = 300;
                sum += Double.Parse(numberToDisplay);

            }
            public override void pressInsertCoin()
            {

            }
            public override void pressGoStop()
            {

                if (count == 3)
                {
                    state = new DisplayAverageTimeState();
                }
                else
                {
                    state = new WaitState();
                }

            }

            public override void tick()
            {
                timer--;
                if (timer == 0)
                {
                    if (count == 3)
                    {
                        state = new DisplayAverageTimeState();
                    }
                    else
                    {
                        state = new WaitState();
                    }
                }
            }
        }

        private class DisplayAverageTimeState : State
        {
            public DisplayAverageTimeState()
            {

                _gui.SetDisplay("Average = " + (sum / 3.0).ToString("0.00"));
                timer = 500;

            }
            public override void pressInsertCoin()
            {

            }
            public override void pressGoStop()
            {
                state = new WaitForCoinState();

            }

            public override void tick()
            {
                timer--;
                if (timer == 0)
                {
                    state = new WaitForCoinState();
                }
            }
        }


    }
}
