﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    public class Batch : Thing
    {
        private String _number;
        private String _name;
        private List<Thing> _items = new List<Thing>();


        public Batch(String _number, String _name) : base(_number, _name)
        {         
            
            this._number = _number;
            this._name = _name;
            
        }



        public void Add(Thing single)
        {
            _items.Add(single);
        }

        //below methods override abstract methods of Thing         **********
        public override void Print()
        {
            for (int i = 0; i < _items.Count; i++)
            {
                
                _items[i].Print();               
                
            }
        }

        
        public override Decimal Total()
        {
            Decimal total = 0;
            for (int i = 0; i < _items.Count; i++)
            {
                total += _items[i].Total();
            }
            return total;
        }

        public override String Name()
        {
            return _name;
        }
        public override String Number()
        {
            return _number;
        }



    }
}
