﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{


    public class Sales
    {
        //list to store orders
        private List<Thing> _orders = new List<Thing>();

        public Sales() { }
        public void AddOrders(Thing order)
        {
            _orders.Add(order);
        }

        //prints the orders
        public void PrintOrders()
        {
            Decimal total = 0;
            Console.WriteLine("Sales:");
            int count = _orders.Count;
            for (int i = 0; i < count; i++)
            {
                if (string.IsNullOrEmpty(_orders[i].Number()) || string.IsNullOrEmpty(_orders[i].Name()))
                {
                    Console.WriteLine("Empty order.");
                    continue;
                }

                if (_orders[i] is Batch)
                {               
                    Console.WriteLine("Batch order: ");                    
                }
                
                 _orders[i].Print();
                 total += _orders[i].Total();
                
                Console.WriteLine("Sales Total: $" + total);
            }

        }


    }
}
