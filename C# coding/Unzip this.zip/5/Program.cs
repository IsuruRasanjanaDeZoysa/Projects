﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    public class Program
    {
        public static void Main(string[] args)
        {
            //Q7,a
            Sales sales = new Sales();

            //Q7,b
            Batch BatchOrderOne = new Batch("#1", "book shop");
            Transaction transactionOne = new Transaction("#1", "Books", 400);
            Transaction transactionTwo = new Transaction("#2", "Pens", 20);
            BatchOrderOne.Add(transactionOne);
            BatchOrderOne.Add(transactionTwo);   
            sales.AddOrders(BatchOrderOne);

            Batch BatchOrderTwo = new Batch("#2", "cafee");
            Transaction transactionThree = new Transaction("#3", "latte", 3);
            Transaction transactionFour = new Transaction("#4", "cappuccino", 2);
            BatchOrderOne.Add(transactionThree);
            BatchOrderOne.Add(transactionFour);
            sales.AddOrders(BatchOrderTwo);


            //Q7,c
            Transaction transactionFive = new Transaction("#5", "bag", 199);
            sales.AddOrders(transactionFive);

            //Q7,d
            Batch BatchOrderThree = new Batch("2", "second batch order");
            Batch nestedBatch = new Batch("2", "nested batch order");
            Transaction transactionSix = new Transaction("#6", "papers", 100);
            Transaction transactionSeven = new Transaction("#7", "wood", 11);
            nestedBatch.Add(transactionSix);
            nestedBatch.Add(transactionSeven);
            BatchOrderThree.Add(nestedBatch);
            sales.AddOrders(BatchOrderThree);

            //Q7,e
            sales.AddOrders(new Batch(null, null));         
            

            //Q7,f
            sales.PrintOrders();
        }
    }
}

