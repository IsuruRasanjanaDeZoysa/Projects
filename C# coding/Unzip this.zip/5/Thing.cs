﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    public abstract class Thing
    {
        private String _number;
        private String _name;

        public Thing(String _number, String _name)
        {
            this._number = _number;
            this._name = _name;
        }

        //here are the abstract methods
        public abstract void Print();
        public abstract Decimal Total();
        public abstract String Name();
        public abstract String Number();
    }
}
