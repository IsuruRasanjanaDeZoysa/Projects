﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    public class Transaction : Thing
    {
        private String _number;
        private String _name;
        private Decimal _amount;


        //constructor
        public Transaction(String _number, String _name, Decimal _amount) : base(_number, _name)
        {
           this. _number = _number;
           this._name = _name;
           this._amount = _amount;
        }

        //below methods override the abstract methods of Thing
        public override void Print()
        {
            Console.WriteLine(_number + ", " + _name + ", $" + _amount);
        }        
        public override Decimal Total()
        {
            return _amount;
        }               
        public override String Number()
        {
            return _number;
        }        
        public override String Name()
        {
            return _name;
        }
    }
}