using System;

public class Account :IComparable<Account>
{
    private decimal _balance;
    private readonly string _name;

    public string Name
    {
        get { return _name; }
    }

    //getter to retrieve _balance
    public decimal Balance
    { get { return _balance; } }

    public Account(string name, decimal balance)
    {
        _name = name;
        _balance = balance;
    }

    public bool Deposit(decimal amount)
    {
        if (amount > 0)
        {
            _balance += amount;
            return true;
        }
        return false;
    }

    public bool Withdraw(decimal amount)
    {
        if (amount > 0 && amount <= _balance)
        {
            _balance -= amount;
            return true;
        }
        return false;
    }

    public void PrintDetails()
    {
        Console.WriteLine("Account Name: " + _name + ", Balance: " + _balance);
    }

    public int CompareTo(Account other)
    {
        if (_balance < other._balance)
        {
            return -1;
        }
        else if (_balance > other._balance)
        {
            return 1;
        }
        else
        {
            return 0;
        }
        
    }
}