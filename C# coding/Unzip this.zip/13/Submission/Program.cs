﻿using Practical_8_1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace Task_8._1
{
    public class Program
    {
        public static void Main(string[] args)
        {
            //create account object to inside to the stack
            Account account1 = new Account("1", 1000);
            Account account2 = new Account("2", 80);
            Account account3 = new Account("3", 10);
            Account account4 = new Account("4", 900);
            Account account5 = new Account("5", 12000);
            Account account6 = new Account("6", 10000);
            Account account7 = new Account("7", 10000);
            Account account8 = new Account("8", 10000);
            Account account9 = new Account("4", 11000);
            Account account10 = new Account("9-credit account", 11000);
            Account account11 = new Account("10-short term deposit", 11000);


            MyStack<Account> Stack = new MyStack<Account>(11);
            Stack.Push(account1);
            Stack.Push(account2);
            Stack.Push(account3);
            Stack.Push(account4);
            Stack.Push(account5);
            Stack.Push(account6);
            Stack.Push(account7);
            Stack.Push(account8);
            Stack.Push(account9);
            Stack.Push(account10);
            Stack.Push(account11);

            Console.WriteLine("Test for Find()");
            //this checks if there is an account with balance equals to 1000
            Console.WriteLine(Stack.Find(x => x.Balance == 1000).Name);
            //this should print 3
            Console.WriteLine(Stack.Find(x => x.Balance < 100).Name);

            //check whether if it returns an ArgumentNullException when criteria is null
            //Account foundAcc=Stack.Find(null);

            //since there is not an account with balance equals to 110 Find method should return a null value so  
            //below line should raise an NullReferenceException
            //Console.WriteLine(Stack.Find(x => x.Balance ==110).Name);

            //search for an account with a strictly positive balance
            Console.WriteLine(Stack.Find(x => x.Balance > 0).Name);

            //search for an account with a balance that doesn't exceed 100
            Console.WriteLine(Stack.Find(x => x.Balance > 0).Name);

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Test for FindAll()");
            //find all account with balance equals to 10000. this should print 8 7 6
            Account[] accounts_balance = Stack.FindAll(x => x.Balance == 10000);
            for (int i = 0; i < accounts_balance.Length; i++)
            {
                Console.Write(accounts_balance[i].Name + " ");
            }
            Console.WriteLine();

            //find all account with name equals to 4. this should print 4 4
            Account[] accounts_name = Stack.FindAll(x => x.Name == "4");
            for (int i = 0; i < accounts_name.Length; i++)
            {
                Console.Write(accounts_name[i].Name + " ");
            }
            Console.WriteLine();

            //find accounts related to credit cards
            Account[] accounts_name_credit = Stack.FindAll(x => Regex.IsMatch(x.Name, @"\bcredit\b", RegexOptions.IgnoreCase));
            for (int i = 0; i < accounts_name_credit.Length; i++)
            {
                Console.Write(accounts_name_credit[i].Name + " ");
            }
            Console.WriteLine();

            //find accounts related to short term deposits
            Account[] accounts_name_stdeposit = Stack.FindAll(x => Regex.IsMatch(x.Name, @"\bshort term deposit\b", RegexOptions.IgnoreCase));
            for (int i = 0; i < accounts_name_stdeposit.Length; i++)
            {
                Console.Write(accounts_name_stdeposit[i].Name + " ");
            }
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Test for RemoveAll()");
            //below line will remove all the account with balance equal to 0. Since there is 3 account
            //that balance equal to 10000 this will print 3
            int numOfRemovedAcc = Stack.RemoveAll(x => x.Balance == 10000);
            Console.WriteLine(numOfRemovedAcc);

            //this will return an ArgumentNullException
            //numOfRemovedAcc = Stack.RemoveAll(null);

            //Since there are two accounts with name equals to 4 this will print 2
            numOfRemovedAcc = Stack.RemoveAll(x => x.Name == "4");
            Console.WriteLine(numOfRemovedAcc);

            //Since there is only one account that has credit in the name this will print 1
            numOfRemovedAcc = Stack.RemoveAll(x => Regex.IsMatch(x.Name, @"\bcredit\b", RegexOptions.IgnoreCase));
            Console.WriteLine(numOfRemovedAcc);

            //Since there is only one account that has short term deposi in the name this will print 1
            numOfRemovedAcc = Stack.RemoveAll(x => Regex.IsMatch(x.Name, @"\bshort term deposit\b", RegexOptions.IgnoreCase));
            Console.WriteLine(numOfRemovedAcc);

            Console.WriteLine();
            Console.WriteLine();

            Console.WriteLine("Tests for Max()");
            //print bank account name with maximum balance. This should print 5
            Console.WriteLine(Stack.Max().Name);
            Console.WriteLine("Tests for Min()");
            //print bank account name with minimum balance. This should print 3
            Console.WriteLine(Stack.Min().Name);
        }
    }
}
