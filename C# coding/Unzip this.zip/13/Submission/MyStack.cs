﻿using System;
using System.Collections.Generic;

namespace Practical_8_1
{

    public class MyStack<T>
    {
        private T[] array;
        public int Count { get; private set; }

        public MyStack(int capacity)
        {
            array = new T[capacity];
            this.Count = 0;
        }

        public void Push(T val)
        {
            if (Count < array.Length) array[Count++] = val;
            else throw new InvalidOperationException("The stack is out of capacity.");
        }

        public T Pop()
        {
            if (Count > 0) return array[--Count];
            else throw new InvalidOperationException("The stack is empty.");
        }

        public T Find(Func<T, bool> criteria)
        {
            if (criteria == null)
            {
                throw new ArgumentNullException();
            }

            int i = Count - 1;
            while (i >= 0)
            {
                if (criteria(array[i]))
                {
                    return array[i];
                }
                i--;
            }

            return default(T);
        }

        public T[] FindAll(Func<T, bool> criteria)
        {
            if (criteria == null)
            {
                throw new ArgumentNullException();
            }
            int count = 0;
            int i=Count - 1;
            while (i >= 0)
            {
                if (criteria(array[i]))
                {
                    count++;
                }
                i--;
            }
            if (count == 0)
            {
                return null;
            }
            else
            {
                T[] matchedValues = new T[count];
                int index = 0;
                i=Count - 1;
                while (i >= 0)
                {
                    if (criteria(array[i]))
                    {
                        matchedValues[index++] = array[i];
                    }
                    i--;
                }                
                return matchedValues;
            }
        }

        public int RemoveAll(Func<T, bool> criteria)
        {
            if (criteria == null)
            {
                throw new ArgumentNullException();
            }
            
            T[] itemsToRemove = FindAll(criteria);
            if (itemsToRemove == null)
            {
                return 0;
            }
            int numberOfitemsToRemove = itemsToRemove.Length;
            int newCount = Count - numberOfitemsToRemove;

            T[] newStack = new T[newCount];

            int index = 0;

            int i = 0;
            while (i < Count)
            {
                int j = 0;
                while (j < numberOfitemsToRemove)
                {
                    if (EqualityComparer<T>.Default.Equals(array[i], itemsToRemove[j]))
                    {

                        break;
                    }
                    j++;
                }
                if (j == numberOfitemsToRemove)
                {
                    newStack[index++] = array[i];
                }
                i++;
            }            
            array = newStack;
            Count = newCount;
            return numberOfitemsToRemove;
        }

        public T Max()
        {
            T max = array[0];
            int i = 1;
            while (i < Count)
            {
                if (Comparer<T>.Default.Compare(array[i], max) > 0)
                {
                    max = array[i];
                }
                i++;
            }
            return max;            
        }

        public T Min()
        {
            T min = array[0];
            int i = 0;
            while (i < Count)
            {
                if (Comparer<T>.Default.Compare(array[i], min) < 0)
                {
                    min = array[i];
                }
                i++;
            }
            return min;
        }
    }

}